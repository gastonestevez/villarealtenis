<?php $__env->startSection('principal'); ?>
<main class="main-editor">

    <div class="caja">
      <i class="fas fa-plus-square"></i>
      <a href="<?php echo e(url('agregarJugador')); ?>">Agregar Usuario </a>
    </div>
  
  <div class="caja">
    <i class="fas fa-minus-square"></i>
      <a href="<?php echo e(url('borrarJugador')); ?>">Eliminar Usuario </a>
    </div>
  
  <div class="caja">
    <i class="fas fa-pencil-alt"></i>
      <a href="modUser.php">Modificar Usuario</a>
    </div>
    <div class="caja">
      <i class="fas fa-table-tennis"></i>
      <a href="<?php echo e(url('realizarMatch')); ?>">Realizar Match</a>
    </div>
  
  </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rankLara\resources\views/editor.blade.php ENDPATH**/ ?>