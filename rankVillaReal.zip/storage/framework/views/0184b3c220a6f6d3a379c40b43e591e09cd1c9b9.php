<?php $__env->startSection('principal'); ?>
<main class="listadoPrincipal main-form col-sm-12">
        <div class="col-sm-12 formYtabla container-fluid row">
                <div class="col-sm-12 col-md-4">
                        <table class="table table-hover table-dark table-striped listadoTabla">
                            <thead>
                                <tr>
                                    <th>Avatar</th>
                                    <th>Nombre</th>
                                    <th>Puesto</th>
                                </tr>
                            </thead>
                            <tbody id="myTable2">
                               
                        </tbody>
                    </table>
                </div>

            <div class="col-sm-12 col-md-6 tablaUltimos3partidos">
                <table class="table table-hover table-dark table-striped">
                        <thead>
                            <tr>
                                <th>Fecha de carga</th>
                                <th>Jugador 1</th>
                                <th>Jugador 2</th>
                                <th>Set 1</th>
                                <th>Set 2</th>
                                <th>Set 3</th>
                                
                            </tr>
                        </thead>
                        <tbody id="myTable1">
                            <?php $__currentLoopData = $ultimosMatches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $match): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <?php echo e(date('d-m-Y',strtotime($match->created_at))); ?>

                                </td>
                                <td>
                                    <?php echo e($match->jugador1()->first()->Nombre); ?> 
                                </td>
                                <td>
                                    <?php echo e($match->jugador2()->get()->first()->Nombre); ?> 
                                </td>
                                <td>
                                    <?php echo e($match->set1); ?> 
                                </td>
                                <td>
                                    <?php echo e($match->set2); ?> 
                                </td>
                                <td>
                                    <?php echo e($match->set3); ?> 
                                </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
        </div>
    </main>
    
<script>
$("body").css("background-image", "url('/storage/<?php echo e($fondo->first()->fondo); ?>')");
$("body").css("background-repeat","cover");

$( document ).ready(function() {
    console.log( "ready!" );
    var listado;
  function updateTable(){
    $.ajax({
      type : 'get',
      url : '<?php echo e(URL::to('obtenerJugadores')); ?>',
      success:function(data){
          listado = JSON.parse(data);
      }
      });
  }
  updateTable();
  setInterval(function() {
    var i = 0;
    $('#myTable2').html(' ');      
    while(i<10 && listado.length>0){
        //console.log(listado[0].Nombre);
        var row = $("<tr />");
        $('#myTable2').append(row);
        row.append($("<td><div class='cajaAvatar'><img src=/storage/"+listado[0].Avatar+"></div></td>"));
        if(listado[0].Puesto <= 16){
            row.append($("<td style=\"color:orange;\">" + listado[0].Nombre+"</td>"));
            row.append($("<td style=\"color:orange;\">" + listado[0].Puesto+"</td>"));
        }else{
            row.append($("<td>" + listado[0].Nombre+"</td>"));
            row.append($("<td>" + listado[0].Puesto+"</td>"));
        }
        listado.shift();
        i++;
    }
    if(listado.length==0){
        updateTable();
    }

}, 3000);
});


  </script>
  <script type="text/javascript">
  $.ajaxSetup({ headers: { 'csrftoken' : '<?php echo e(csrf_token()); ?>' } });
  </script>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rankLara\resources\views/listadoPartidos.blade.php ENDPATH**/ ?>