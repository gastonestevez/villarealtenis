<header>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="<?php echo e(url("/login")); ?>">
            <img src="<?php echo e(url('/logo.png')); ?>" width="35px" alt="logo">
          </a>
      <a class="navbar-brand" href="<?php echo e(url('listado')); ?>">Villa Real Tenis</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarNavDropdown">
        <ul class="navbar-nav">
          <?php if(auth()->guard()->guest()): ?>
          <?php else: ?>
          <li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              <i class="fas fa-edit"></i> Opciones
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdownMenuLink">
                    <a class="dropdown-item" href="<?php echo e(url('agregarJugador')); ?>">Altas / Bajas de Jugadores</a>
                    <a class="dropdown-item" href="<?php echo e(url('historialMatch')); ?>">Historial de Partidos</a>
                    <a class="dropdown-item" href="<?php echo e(url('match')); ?>">Match</a>
                    <a class="dropdown-item" href="<?php echo e(url('listado')); ?>">Listado</a>
                    <a class="dropdown-item" href="<?php echo e(url('entorno')); ?>">Configurar</a>
                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault();
                                      document.getElementById('logout-form').submit();">
                         <?php echo e(__('Logout')); ?>

                     </a>

                     <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                         <?php echo csrf_field(); ?>
                     </form>  
                </div>
          </li>
          <?php endif; ?>

        </ul>
      </div>
    </nav>
    </header><?php /**PATH C:\xampp\htdocs\rankLara\resources\views/navegacion.blade.php ENDPATH**/ ?>