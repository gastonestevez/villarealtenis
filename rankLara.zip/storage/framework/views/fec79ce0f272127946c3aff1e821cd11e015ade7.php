<?php $__env->startSection('principal'); ?>
<main class="container main-form">
    <div class="descripcion col-md-12">
        <h1><i class="fas fa-user"></i> Modificacion de entorno</h1>
        <p><i class="fas fa-pen"></i> En esta seccion puede cambiar diferentes variables de entorno.</p>
    </div>

    <div class="formYtabla">
        <div class="formulario col-md-4 mx-auto">
            <form action="<?php echo e(url('/guardarFondo')); ?>" method="post" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                        <label for="fondo"><i class="fas fa-angle-double-right"></i> Fondo</label><br>
                        <input type="file" name="fondo" placeholder="Fondo">
                </div>
                <input type="hidden" name="oculto">
                <button class="btn btn-light d-block mt-4" type="submit">Modificar</button>
            </form>
        </div>
    </div>

    <div class="formYtabla formulario my-2 mx-auto">
        <h2>Fondo Actual</h2>
        <img src="storage/<?php echo e($entornoActual->first()->fondo); ?>" alt="fondo" width="200">
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\rankLara\resources\views/entorno.blade.php ENDPATH**/ ?>